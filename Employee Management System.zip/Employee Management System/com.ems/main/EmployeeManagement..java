package com.ems.main;

import com.ems.model.*;
import com.ems.service.EmployeeService;

public class EmployeeManagementApp {

    public static void main(String[] args) {

        EmployeeService service =
                new EmployeeService();

        Address address1 =
                new Address(
                        "Gandhi Street",
                        "Erode",
                        "Tamil Nadu",
                        "638001");

        Address address2 =
                new Address(
                        "Anna Nagar",
                        "Coimbatore",
                        "Tamil Nadu",
                        "641001");

        Address address3 =
                new Address(
                        "Main Road",
                        "Salem",
                        "Tamil Nadu",
                        "636001");

        Employee emp1 =
                new FullTimeEmployee(
                        101,
                        "Aravindhan",
                        Department.IT,
                        address1,
                        50000);

        Employee emp2 =
                new PartTimeEmployee(
                        102,
                        "Kumar",
                        Department.HR,
                        address2,
                        400,
                        100);

        Employee emp3 =
                new ContractEmployee(
                        103,
                        "Ravi",
                        Department.FINANCE,
                        address3,
                        35000);

        service.addEmployee(emp1);
        service.addEmployee(emp2);
        service.addEmployee(emp3);

        System.out.println("\n===== ALL EMPLOYEES =====");

        service.displayAllEmployees();

        try {

            System.out.println(
                    "\n===== SEARCH EMPLOYEE =====");

            Employee employee =
                    service.searchEmployee(102);

            employee.displayBasicInfo();

            System.out.println(
                    "Salary : ₹"
                            + employee.calcSalary());

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

        try {

            System.out.println(
                    "\n===== REMOVE EMPLOYEE =====");

            service.removeEmployee(103);

            System.out.println(
                    "\n===== UPDATED LIST =====");

            service.displayAllEmployees();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }
}