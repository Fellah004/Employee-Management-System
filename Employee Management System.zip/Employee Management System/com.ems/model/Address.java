package com.ems.model;

public record Address(
        String street,
        String city,
        String state,
        String pincode) {
}